//
//  ViewController.m
//  ZTPayDemo
//
//  Created by tony on 16/10/21.
//  Copyright © 2016年 ZThink. All rights reserved.
//

#import "ViewController.h"
#import "WXApi.h"
#import "WXApiObject.h"
#import <AlipaySDK/AlipaySDK.h>
#import "AppDelegate.h"
#import "UPPaymentControl.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //模拟下单，为了安全，都是在服务器统一下单
    
    
    
    
}
#pragma mark --life cycle
-(void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    //判断用户是否安装了微信
    if ([WXApi isWXAppInstalled]) {
        //监听微信支付通知
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getOrderPayResult:) name:@"pay" object:nil];
    }
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    //判断用户是否安装了微信
    if ([WXApi isWXAppInstalled]) {
        //移除监听
        [[NSNotificationCenter defaultCenter]removeObserver:self name:@"pay" object:nil];
    }

}

#pragma mark --- 模拟微信支付
-(void)WXPay{
/**>
 * 1.上传购物车商品列表到服务器
 * 2.服务器返回订单号，商户ID等信息
 * 3.调起微信支付，---这是我们现在要模拟做的
 *{
 "appid": "wxb4ba3c02aa476ea1",
 "noncestr": "d1e6ecd5993ad2d06a9f50da607c971c",
 "package": "Sign=WXPay",
 "partnerid": "10000100",
 "prepayid": "wx20160218122935e3753eda1f0066087993",
 "timestamp": "1455769775",
 "sign": "F6DEE4ADD82217782919A1696500AF06"
 }
 */
    //调起支付前，要确定订单没有问题--即服务器返回数据正常
    NSDictionary * dataDict = [NSDictionary dictionary];//模拟服务器返回的订单信息
    NSMutableString *stamp  = [dataDict objectForKey:@"timestamp"];
    
    // 调起微信支付
    PayReq* req             = [[PayReq alloc] init];
    req.openID              = [dataDict objectForKey:@"appid"];         // 新添加
    req.partnerId           = [dataDict objectForKey:@"partnerid"];
    req.prepayId            = [dataDict objectForKey:@"prepayid"];
    req.nonceStr            = [dataDict objectForKey:@"noncestr"];
    req.timeStamp           = stamp.intValue;
    req.package             = [dataDict objectForKey:@"package"];
    req.sign                = [dataDict objectForKey:@"sign"];
    [WXApi sendReq:req];
    
//注意，微信充值的话也是这样处理，但是要做一个区分，不然你自己都分不清楚是支付的还是充值的

}


#pragma mark --- 模拟支付宝支付
-(void)alipay{
/**>
 * 首先，要考虑一个问题：
 * 1.用户安装了支付宝客户端
 * 2. 用户没有安装支付宝客户端，调起H5
 * 3.lian
 */

    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"alipay:"]]) {
        
        [[AlipaySDK defaultService]payOrder:@"填如从你们服务器请求的payorder" fromScheme:@"你的工程名字" callback:^(NSDictionary *resultDic) {
            if (((NSString *)[resultDic objectForKey:@"resultStatus"]).intValue == 9000) {
                
               //支付成功，支付宝的支付成功有支付宝后台告诉我们后台，不需要我们管理，我们只需要将支付成功的信息告诉用户
                //code here ....
                
                
            }else{
            
            //支付取消的操做，我们要将取消的订单告诉我们后台
                //code here
            
            }
            
            
        }];
    }else
    {//没有安装支付宝客户端，调起H5支付
        
        
        NSDictionary *dataDict = [NSDictionary dictionary];
        
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[dataDict objectForKey:@"payParams"]]];
        
        // 退出app
        AppDelegate *app = [UIApplication sharedApplication].delegate;
        UIWindow *window = app.window;
        
        [UIView animateWithDuration:0.65f animations:^{
            window.alpha = 0;
            CGFloat y = window.bounds.size.height;
            CGFloat x = window.bounds.size.width / 2;
            window.frame = CGRectMake(x, y, 0, 0);
        } completion:^(BOOL finished) {
            exit(0);
        }];

    }

}


#pragma mark -- 模拟银联支付
-(void)uppay{

//同样的道理，从服务器获取订单流水号
    
    /**
     *  支付接口
     *
     *  @param tn             订单信息，交易流水号，
     *  @param schemeStr      你的工程名字
     *  @param mode           支付环境"00"代表接入生产环境（正式版本需要）"01"代表接入开发测试环境
     *  @param viewController 启动支付控件的viewController
     *  @return 返回成功失败
     */
[[UPPaymentControl defaultControl] startPay:@"tn-由后台给我们"fromScheme:@"ZTPayDemo" mode:@"01" viewController:self];

}


//处理得到的结果
-(void)getOrderPayResult:(NSNotification *)notification{
    if ([notification.object isEqualToString:@"successs"]) {
        //跳转到支付成功的界面，并且要告诉服务器支付成功了
        //code here.....
    }else
    {
    //支付失败，里面有很多情况：支付取消，未能支付成功...
        //code here....
    }



}
@end
